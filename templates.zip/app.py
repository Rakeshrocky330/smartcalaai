import matplotlib
matplotlib.use('Agg')

import matplotlib.pyplot as plt
import numpy as np
import os
import json
from datetime import datetime
from itsdangerous import URLSafeTimedSerializer
import smtplib
from email.message import EmailMessage
from urllib.parse import urlencode
from urllib.request import Request, urlopen
from flask_login import (
    LoginManager,
    UserMixin,
    login_user,
    logout_user,
    login_required,
    current_user
)
from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, send_from_directory, Response
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from sympy import symbols, Eq, solve, sympify

app = Flask(__name__)
app.secret_key = "smartcalc_secret_key"

app.config['SECRET_KEY'] = 'smartcalcsecret'

app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///database.db'

# Mail configuration (set these in environment or change here)
app.config.setdefault('MAIL_SERVER', os.environ.get('MAIL_SERVER', ''))
app.config.setdefault('MAIL_PORT', int(os.environ.get('MAIL_PORT') or 0))
app.config.setdefault('MAIL_USERNAME', os.environ.get('MAIL_USERNAME', ''))
app.config.setdefault('MAIL_PASSWORD', os.environ.get('MAIL_PASSWORD', ''))
app.config.setdefault('MAIL_DEFAULT_SENDER', os.environ.get('MAIL_DEFAULT_SENDER', os.environ.get('MAIL_USERNAME', 'noreply@localhost')))
app.config.setdefault('MAIL_USE_TLS', os.environ.get('MAIL_USE_TLS', 'true').lower() in ('1','true','yes'))
app.config.setdefault('MAIL_USE_SSL', os.environ.get('MAIL_USE_SSL', 'false').lower() in ('1','true','yes'))
app.config.setdefault('GOOGLE_CLIENT_ID', os.environ.get('GOOGLE_CLIENT_ID', ''))
app.config.setdefault('GOOGLE_CLIENT_SECRET', os.environ.get('GOOGLE_CLIENT_SECRET', ''))

serializer = URLSafeTimedSerializer(app.config['SECRET_KEY'])

db = SQLAlchemy(app)

login_manager = LoginManager()
login_manager.init_app(app)

login_manager.login_view = 'login'

# ---------------- USER MODEL ----------------

class User(UserMixin, db.Model):

    id = db.Column(
        db.Integer,
        primary_key=True
    )

    fullname = db.Column(
        db.String(100)
    )

    email = db.Column(
        db.String(120),
        unique=True
    )

    education = db.Column(
        db.String(50)
    )

    username = db.Column(
        db.String(100),
        unique=True
    )

    password = db.Column(
        db.String(200)
    )
# ---------------- HISTORY MODEL ----------------

class Calculation(db.Model):

    id = db.Column(db.Integer, primary_key=True)

    calculation = db.Column(db.String(200))


class MCQAttempt(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer)
    score = db.Column(db.Integer)
    total = db.Column(db.Integer)
    details = db.Column(db.Text)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)

class Feedback(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)
    message = db.Column(db.Text, nullable=False)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)

# ---------------- LOGIN LOADER ----------------

@login_manager.user_loader
def load_user(user_id):

    # Use Session.get to avoid SQLAlchemy legacy Query.get warning
    try:
        return db.session.get(User, int(user_id))
    except Exception:
        return None

# ---------------- HOME ----------------

@app.route('/')
@login_required
def home():

    return render_template(
        "index.html",
        username=current_user.username
    )

# ---------------- REGISTER ----------------

@app.route('/register', methods=['GET', 'POST'])
def register():

    if request.method == 'POST':

        fullname = request.form['fullname']

        email = request.form['email']

        education = request.form['education']

        username = request.form['username']

        password = request.form['password']

        confirm_password = request.form['confirm_password']

        # Password Match Check
        if password != confirm_password:

            flash("Passwords do not match", "error")
            return redirect(url_for('register'))

        # Password Length Check
        if len(password) < 6:

            flash("Password must be at least 6 characters", "error")
            return redirect(url_for('register'))
        # Duplicate Username
        existing_user = User.query.filter_by(
            username=username
        ).first()

        if existing_user:

            flash("Username already exists", "error")
            return redirect(url_for('register'))
        # Duplicate Email
        existing_email = User.query.filter_by(
            email=email
        ).first()

        if existing_email:

           flash("Email already exists", "error")
           return redirect(url_for('register'))

        user = User(

            fullname=fullname,

            email=email,

            education=education,

            username=username,

            password=generate_password_hash(password)

        )

        db.session.add(user)

        db.session.commit()
        flash("Registration Successful! Please Login.", "success")

        return redirect(url_for('login'))

    return render_template('register.html')

# ---------------- LOGIN ----------------

@app.route('/login', methods=['GET', 'POST'])
def login():

    if request.method == 'POST':

        username = request.form['username']

        password = request.form['password']

        user = User.query.filter_by(
            username=username
        ).first()

        if user and check_password_hash(
            user.password,
            password
        ):
            login_user(user)
            return redirect(
               url_for('dashboard')
           )

        flash('Invalid username or password.', 'error')

    return render_template(
        "login.html",
        google_enabled=bool(app.config['GOOGLE_CLIENT_ID'] and app.config['GOOGLE_CLIENT_SECRET'])
    )

def _google_oauth_post(url, data):
    encoded = urlencode(data).encode('utf-8')
    req = Request(url, data=encoded, headers={'Content-Type': 'application/x-www-form-urlencoded'})
    with urlopen(req, timeout=15) as resp:
        return json.loads(resp.read().decode('utf-8'))


def _google_oauth_get(url, access_token):
    req = Request(url, headers={'Authorization': f'Bearer {access_token}'})
    with urlopen(req, timeout=15) as resp:
        return json.loads(resp.read().decode('utf-8'))


@app.route('/login/google')
def login_google():
    client_id = app.config['GOOGLE_CLIENT_ID']
    client_secret = app.config['GOOGLE_CLIENT_SECRET']
    if not client_id or not client_secret:
        flash('Google login is not configured yet. Please use your username and password for now.', 'error')
        return redirect(url_for('login'))

    redirect_uri = url_for('google_callback', _external=True)
    params = {
        'client_id': client_id,
        'redirect_uri': redirect_uri,
        'response_type': 'code',
        'scope': 'openid email profile',
        'access_type': 'offline',
        'prompt': 'select_account'
    }
    auth_url = 'https://accounts.google.com/o/oauth2/v2/auth?' + urlencode(params)
    return redirect(auth_url)


@app.route('/login/google/callback')
def google_callback():
    code = request.args.get('code')
    if not code:
        flash('Google login failed. No authorization code received.', 'error')
        return redirect(url_for('login'))

    client_id = app.config['GOOGLE_CLIENT_ID']
    client_secret = app.config['GOOGLE_CLIENT_SECRET']
    redirect_uri = url_for('google_callback', _external=True)

    try:
        token_response = _google_oauth_post(
            'https://oauth2.googleapis.com/token',
            {
                'code': code,
                'client_id': client_id,
                'client_secret': client_secret,
                'redirect_uri': redirect_uri,
                'grant_type': 'authorization_code'
            }
        )
    except Exception:
        flash('Google login failed while requesting tokens.', 'error')
        return redirect(url_for('login'))

    access_token = token_response.get('access_token')
    if not access_token:
        flash('Google login failed. Could not obtain access token.', 'error')
        return redirect(url_for('login'))

    try:
        profile = _google_oauth_get('https://www.googleapis.com/oauth2/v3/userinfo', access_token)
    except Exception:
        flash('Google login failed while fetching account details.', 'error')
        return redirect(url_for('login'))

    email = profile.get('email')
    fullname = profile.get('name') or profile.get('given_name') or 'Google User'
    if not email:
        flash('Google login failed. Email was not provided by Google.', 'error')
        return redirect(url_for('login'))

    user = User.query.filter_by(email=email).first()
    if not user:
        username_base = email.split('@')[0]
        username = username_base
        counter = 1
        while User.query.filter_by(username=username).first():
            username = f'{username_base}{counter}'
            counter += 1

        user = User(
            fullname=fullname,
            email=email,
            education='Unknown',
            username=username,
            password=generate_password_hash(os.urandom(16).hex())
        )
        db.session.add(user)
        db.session.commit()

    login_user(user)
    return redirect(url_for('dashboard'))

# ---------------- LOGOUT ----------------

@app.route('/logout')
def logout():

    logout_user()

    return redirect(url_for('login'))


# ---------------- FORGOT / RESET PASSWORD ----------------
def send_email(to_email, subject, body):
    server = app.config.get('MAIL_SERVER')
    port = app.config.get('MAIL_PORT')
    username = app.config.get('MAIL_USERNAME')
    password = app.config.get('MAIL_PASSWORD')
    sender = app.config.get('MAIL_DEFAULT_SENDER')
    use_tls = app.config.get('MAIL_USE_TLS', True)
    use_ssl = app.config.get('MAIL_USE_SSL', False)

    if not server or not port:
        print('Email not sent (SMTP server or port not configured).')
        print('To:', to_email)
        print('Subject:', subject)
        print(body)
        return False

    try:
        msg = EmailMessage()
        msg['Subject'] = subject
        msg['From'] = sender
        msg['To'] = to_email
        msg.set_content(body)

        if use_ssl:
            smtp = smtplib.SMTP_SSL(server, port, timeout=10)
        else:
            smtp = smtplib.SMTP(server, port, timeout=10)

        with smtp:
            if not use_ssl and use_tls:
                smtp.starttls()
            if username and password:
                smtp.login(username, password)
            smtp.send_message(msg)
        return True
    except Exception as e:
        print('Error sending email:', e)
        return False


@app.route('/forgot', methods=['GET', 'POST'])
def forgot_password():
    if request.method == 'POST':
        email = request.form.get('email')
        user = User.query.filter_by(email=email).first()
        if not user:
            flash('If that email exists, a reset link will be sent.', 'info')
            return redirect(url_for('login'))

        token = serializer.dumps(user.email, salt='password-reset-salt')
        link = url_for('reset_password', token=token, _external=True)
        body = f'Hello {user.username},\n\nTo reset your password, click the link below (valid 1 hour):\n\n{link}\n\nIf you did not request this, ignore this email.'
        sent = send_email(user.email, 'SmartCalc Password Reset', body)
        if not sent:
            flash('Email delivery is not configured. Please contact the administrator or configure SMTP settings before using password reset.', 'error')
            return render_template('forgot.html')

        flash('If that email exists, a reset link will be sent to that address.', 'info')
        return redirect(url_for('login'))

    return render_template('forgot.html')


@app.route('/reset/<token>', methods=['GET', 'POST'])
def reset_password(token):
    try:
        email = serializer.loads(token, salt='password-reset-salt', max_age=3600)
    except Exception:
        flash('The reset link is invalid or has expired.', 'error')
        return redirect(url_for('login'))

    user = User.query.filter_by(email=email).first()
    if not user:
        flash('Invalid user.', 'error')
        return redirect(url_for('login'))

    if request.method == 'POST':
        password = request.form.get('password')
        confirm = request.form.get('confirm_password')
        if password != confirm:
            flash('Passwords do not match.', 'error')
            return redirect(url_for('reset_password', token=token))
        if len(password) < 6:
            flash('Password must be at least 6 characters.', 'error')
            return redirect(url_for('reset_password', token=token))

        user.password = generate_password_hash(password)
        db.session.commit()

        # send confirmation
        try:
            send_email(user.email, 'Your SmartCalc password was changed', 'Your password has been successfully changed.')
        except Exception:
            pass

        flash('Your password has been updated. Please login.', 'success')
        return redirect(url_for('login'))

    return render_template('reset.html')

# ---------------- SAVE HISTORY ----------------

@app.route('/save', methods=['POST'])
@login_required
def save():

    data = request.get_json()

    calculation_text = data.get("calculation")

    new_calculation = Calculation(
        calculation=calculation_text
    )

    db.session.add(new_calculation)

    db.session.commit()

    return jsonify({
        "message": "Saved"
    })

# ---------------- GET HISTORY ----------------

@app.route('/history')
@login_required
def history():

    calculations = Calculation.query.all()

    history_data = []

    for item in calculations:

        history_data.append(item.calculation)

    return jsonify(history_data)

# ---------------- SOLVE EQUATION ----------------

@app.route('/solve', methods=['POST'])
@login_required
def solve_equation():

    data = request.get_json()

    equation = data.get("equation")

    try:

        x = symbols('x')

        left, right = equation.split('=')

        left_expr = sympify(left)

        right_expr = sympify(right)

        eq = Eq(left_expr, right_expr)

        answer = solve(eq, x)

        return jsonify({
            "solution": str(answer)
        })

    except Exception as e:

        return jsonify({
            "solution": "Invalid Equation"
        })

# ---------------- GRAPH ----------------

@app.route('/graph', methods=['POST'])
@login_required
def graph():

    data = request.get_json()

    expression = data.get("expression")

    try:

        x = np.linspace(-10, 10, 400)

        y = eval(expression, {"x": x, "np": np})

        plt.figure(figsize=(6,4))

        plt.plot(x, y)

        plt.grid(True)

        plt.title(expression)

        static_folder = os.path.join(
            app.root_path,
            'static'
        )

        graphs_folder = os.path.join(
            static_folder,
            'graphs'
        )

        os.makedirs(graphs_folder, exist_ok=True)

        graph_path = os.path.join(
            graphs_folder,
            'graph.png'
        )

        plt.savefig(graph_path)

        plt.close()

        return jsonify({
            "graph_url":
            "/static/graphs/graph.png"
        })

    except Exception as e:

        print("GRAPH ERROR:", e)

        return jsonify({
            "graph_url":""
        })

# ---------------- MCQ API ----------------
@app.route('/api/mcq')
@login_required
def api_mcq():
    static_path = os.path.join(app.root_path, 'static', 'mcq_questions.json')
    try:
        with open(static_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
    except Exception:
        return jsonify({'error': 'Questions not available'}), 500

    # gather previously seen question IDs for this user
    seen_ids = set()
    attempts = MCQAttempt.query.filter_by(user_id=current_user.id).all()
    for attempt in attempts:
        try:
            details = json.loads(attempt.details or '[]')
            for item in details:
                if isinstance(item, dict) and item.get('id') is not None:
                    seen_ids.add(item['id'])
        except Exception:
            continue

    import random
    random.shuffle(data)

    unseen = [q for q in data if q.get('id') not in seen_ids]
    remaining = [q for q in data if q.get('id') in seen_ids]

    if len(unseen) >= 10:
        pick = unseen[:10]
    else:
        pick = unseen[:]
        random.shuffle(remaining)
        needed = 10 - len(pick)
        pick.extend(remaining[:needed])
        if len(pick) == 0:
            pick = data[:10] if len(data) >= 10 else data[:]

    used_repeat = any(q.get('id') in seen_ids for q in pick)
    unseen_count = sum(1 for q in pick if q.get('id') not in seen_ids)

    # strip answers before sending
    public = []
    for q in pick:
        public.append({
            'id': q.get('id'),
            'level': q.get('level'),
            'question': q.get('question'),
            'options': q.get('options')
        })

    return jsonify({
        'questions': public,
        'used_repeat_questions': used_repeat,
        'unseen_count': unseen_count,
        'repeat_count': len(pick) - unseen_count,
        'total_requested': len(pick)
    })


@app.route('/api/mcq/submit', methods=['POST'])
@login_required
def api_mcq_submit():
    payload = request.get_json() or {}
    answers = payload.get('answers') or []

    static_path = os.path.join(app.root_path, 'static', 'mcq_questions.json')
    try:
        with open(static_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
    except Exception:
        return jsonify({'error': 'Questions not available'}), 500

    # map id -> correct index
    answer_map = {q['id']: q['answer_index'] for q in data}

    score = 0
    total = len(answers)
    per_level = {}

    details = []
    for a in answers:
        qid = a.get('id')
        sel = a.get('selected')
        correct = answer_map.get(qid)
        is_correct = (sel == correct)
        if is_correct: score += 1
        # find level from data
        lvl = next((q['level'] for q in data if q['id']==qid), 'unknown')
        per_level.setdefault(lvl, {'total':0,'correct':0})
        per_level[lvl]['total'] += 1
        if is_correct: per_level[lvl]['correct'] += 1
        details.append({'id': qid, 'selected': sel, 'correct': correct, 'correct_bool': is_correct})

    # store attempt
    attempt = MCQAttempt(
        user_id = current_user.id if current_user and hasattr(current_user, 'id') else None,
        score = score,
        total = total,
        details = json.dumps(details)
    )
    db.session.add(attempt)
    db.session.commit()

    per_level_pct = {}
    for level, item in per_level.items():
        per_level_pct[level] = int((item['correct'] / item['total']) * 100) if item['total'] else 0

    strengths = [level for level, pct in per_level_pct.items() if pct >= 75]
    needs_practice = [level for level, pct in per_level_pct.items() if pct < 50]

    if total == 0:
        overall_advice = 'No answers submitted. Try the quiz again to receive a performance summary.'
    else:
        performance = score / total
        if performance >= 0.8:
            overall_advice = 'Excellent work! You have a strong grasp of the material.'
        elif performance >= 0.5:
            overall_advice = 'Good effort. Focus on the weaker topics to boost your score.'
        else:
            overall_advice = 'Keep practicing. Strengthen your fundamentals and try again.'

    suggestions = []
    if strengths:
        suggestions.append('Strong areas: ' + ', '.join(strengths).capitalize())
    if needs_practice:
        suggestions.append('Needs more practice: ' + ', '.join(needs_practice).capitalize())
    if not strengths and not needs_practice:
        suggestions.append('Your performance is balanced across levels. Keep practicing all topics.')

    return jsonify({
        'score': score,
        'total': total,
        'per_level': per_level,
        'per_level_pct': per_level_pct,
        'details': details,
        'attempt_id': attempt.id,
        'advice': overall_advice,
        'suggestions': suggestions
    })
# ---------------- MAIN ----------------
# ---------------- AI CHATBOT ----------------

@app.route('/ask_ai', methods=['POST'])
@login_required
def ask_ai():

    data = request.get_json(silent=True) or {}
    question = (data.get("question") or "").strip()

    if not question:
        return jsonify({"answer": "Please ask a math question."})

    question = question.lower()

    answer = ""

    if "area" in question and "circle" in question:

        answer = "Formula: π × r²"

    elif "circumference" in question and "circle" in question:

        answer = "Circumference of a circle is 2πr."

    elif "pythagor" in question or "hypotenuse" in question:

        answer = "Formula: a² + b² = c²"

    elif "quadratic" in question:

        answer = "x = (-b ± √(b²-4ac))/2a"

    elif "interest" in question:

        if "compound" in question:
            answer = "Compound interest: A = P(1 + r/n)^(n t), where P is principal, r is annual rate, n is compounding periods per year, and t is years."
        elif "simple" in question:
            answer = "Simple interest: SI = (P × R × T) / 100."
        else:
            answer = "Simple interest: SI = (P × R × T) / 100. Compound interest: A = P(1 + r/n)^(n t)."

    elif "sin" in question:

        answer = "sin(x) gives the sine of angle x in a right triangle or on the unit circle."

    elif "cos" in question:

        answer = "cos(x) gives the cosine of angle x in a right triangle or on the unit circle."

    elif "tan" in question:

        answer = "tan(x) gives the tangent of angle x, equal to sin(x)/cos(x)."

    elif "derivative" in question or "differentiate" in question:

        answer = "A derivative measures how a function changes. For example, the derivative of x² is 2x."

    elif "integral" in question or "integrate" in question:

        answer = "An integral gives the area under a curve. The integral of x is x²/2 + C."

    elif "algebra" in question:

        answer = "Algebra uses symbols to represent numbers and solve equations, such as x + 3 = 7."

    elif "calculus" in question:

        answer = "Calculus studies change (derivatives) and accumulation (integrals)."

    elif "function" in question:

        answer = "A function maps each input to exactly one output, like f(x) = x²."

    elif "triangle" in question:

        answer = "A triangle has three sides and three angles. The angles sum to 180 degrees."

    elif "circle" in question:

        answer = "A circle is the set of points at equal distance from the center. Radius r gives circumference 2πr."

    else:

        answer = f"I heard: '{question}'. I can answer many math topics such as formulas, definitions, or basic rules. Try asking in a specific way, like 'area of a circle', 'Pythagoras', 'quadratic formula', 'simple interest', 'sin x', or 'derivative of x^2'."

    return jsonify({
        "answer": answer
    })
@app.route('/favicon.ico')
def favicon():

    static_path = os.path.join(app.root_path, 'static', 'favicon.ico')

    if os.path.exists(static_path):

        return send_from_directory(os.path.join(app.root_path, 'static'), 'favicon.ico')

    svg = ('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16">'
           '<rect width="16" height="16" fill="#2b6cb0"/>'
           '<text x="8" y="11" font-size="10" font-family="Arial" fill="white" text-anchor="middle">S</text>'
           '</svg>')

    return Response(svg, mimetype='image/svg+xml')
@app.route('/profile')
@login_required
def profile():

    attempts = MCQAttempt.query.filter_by(
        user_id=current_user.id
    ).order_by(MCQAttempt.timestamp.desc()).all()

    tests_taken = len(attempts)
    total_questions = sum(a.total for a in attempts)
    total_score = sum(a.score for a in attempts)
    average_score = round((total_score / total_questions * 100) if total_questions else 0, 1)
    last_attempt = attempts[0] if attempts else None

    return render_template(
        'profile.html',
        user=current_user,
        tests_taken=tests_taken,
        total_questions=total_questions,
        average_score=average_score,
        last_attempt=last_attempt
    )
@app.route('/dashboard')
@login_required
def dashboard():

    attempts = MCQAttempt.query.filter_by(
        user_id=current_user.id
    ).order_by(MCQAttempt.timestamp.desc()).all()

    tests_taken = len(attempts)
    total_questions = sum(a.total for a in attempts)
    average_score = 0
    if tests_taken:
        average_score = round(
            sum((a.score / a.total) if a.total else 0 for a in attempts) /
            tests_taken * 100
        )

    graphs_generated = Calculation.query.count()

    recent_activity = [
        {
            'when': a.timestamp.strftime('%b %d, %Y %H:%M'),
            'score': a.score,
            'total': a.total,
        }
        for a in attempts[:5]
    ]

    return render_template(
        'dashboard.html',
        tests_taken=tests_taken,
        average_score=average_score,
        questions_solved=total_questions,
        graphs_generated=graphs_generated,
        recent_activity=recent_activity
    )
@app.route('/calculator')
@login_required
def calculator_page():

    return render_template(
        'calculator.html'
    )


@app.route('/solver')
@login_required
def solver_page():

    return render_template(
        'solver.html'
    )


@app.route('/graph')
@login_required
def graph_page():
    return render_template('graph.html')


@app.route('/ai')
@login_required
def ai_page():
    return render_template('ai.html')


@app.route('/mcq')
@login_required
def mcq_page():
    return render_template('mcq.html')


@app.route('/feedback', methods=['GET', 'POST'])
@login_required
def feedback_page():
    if request.method == 'POST':
        data = request.get_json() or {}
        message = (data.get('message') or '').strip()
        if not message:
            return jsonify({'status': 'error', 'message': 'Feedback cannot be blank.'}), 400

        feedback = Feedback(
            user_id=current_user.id,
            message=message
        )
        db.session.add(feedback)
        db.session.commit()

        lower = message.lower()
        suggestions = []
        note = ''
        if any(keyword in lower for keyword in ['bug', 'issue', 'error', 'problem', 'crash', 'wrong']):
            suggestions.append('We will investigate this issue and aim to fix it quickly.')
            suggestions.append('Try refreshing the page or restarting the app if it happens again.')
            note = 'Interesting fact: Most app improvements come from user feedback like yours.'
        elif any(keyword in lower for keyword in ['feature', 'add', 'support', 'option', 'suggest']):
            suggestions.append('Great idea! We will consider this feature for a future update.')
            suggestions.append('You can also use the AI assistant for instant explanations while we work on improvements.')
            note = 'Fun fact: Math apps often evolve fastest when users suggest real use cases.'
        elif any(keyword in lower for keyword in ['love', 'great', 'awesome', 'nice', 'good', 'thanks']):
            suggestions.append('Thank you! Keep exploring the AI assistant and MCQ practice.')
            suggestions.append('If you want, try the graph visualizer next for more math fun.')
            note = 'Did you know? Regular practice improves retention by up to 70%.'
        else:
            suggestions.append('Thanks for your feedback — it helps us improve every day.')
            suggestions.append('We appreciate your input and will review it carefully.')
            note = 'Tip: Your feedback helps shape the next version of SmartCalc AI.'

        return jsonify({
            'status': 'success',
            'message': 'Thank you! Your feedback has been submitted.',
            'suggestions': suggestions,
            'note': note
        })

    return render_template('feedback.html')

if __name__ == "__main__":

    with app.app_context():
        db.create_all()

    app.run(debug=True)